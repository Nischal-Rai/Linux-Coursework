	#!/bin/bash
	
	#Program starts
	#Choices method asks the user if the user wants to run the program or not.
	#If the user select to run the program then the showCountry method is called or the user chooses not ot run the program then the program gets terminated.
	Choices(){
		echo ""
		echo "^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^"
		echo "Enter Yes to continue playing / No to exit乁[ᓀ˵▾˵ᓂ]ㄏ :"
		echo "^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^"
		read answer
		if [ "$answer" == Yes ]
		then
			showCountry
		elif [ "$answer" == No ]
			then
				echo ""
				echo "*~*~*~*~*~*~*~*~*~*~*~*~*~**~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*"
				echo "Thanks For Playing! Feel free to play whenever u want (灬º‿º灬)."
				echo "*~*~*~*~*~*~*~*~*~*~*~*~**~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*"
				exit
			else
				echo "~~~~~~~~~~~~~~~~~~~~~"
				echo "Choose Yes/NO (⇀‸↼‶):"
				echo "~~~~~~~~~~~~~~~~~~~~~"
				Choices
		fi 
	}
	#The showFiles method displays the details of chosenPlayer.
	# If  the file of chosenPlayer does not exist then an error message is displayed and take the user back to showCountry Function.
	showFiles(){
		if [ -f $1 ]
		then
			echo "$2"
			cat $1
			Choices
		else
			echo "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
			echo "                  YOU LOST                        "
			echo "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
			echo ""
			echo "**************************************************"
			echo "      Please!!! Play the game from Phase 1       "
			echo "**************************************************"
			showCountry
		fi
	}
	#Selection of the three parameters is given to the user. The three parameter are again called by select statement. 
	#Case statement is used for displaying the files. 
	#showFiles function is used for viewing the files.
	# If the user inputs the wrong number while selecting then an error message is displayed.
	chosenPlayer(){
		if [ $# == 3 ]
		then
		echo ""
		echo "-----------------------Phase 3-------------------------------------"
		echo "Here are the three players that you have selected:"
		PS3="Please select your favourite player:"
		select selectedPlayer in $players
			do
				case $selectedPlayer in
					"LM")	showFiles LionelMessi LM
					break;;
					"NJ") 	showFiles NeymarJunior NJ
					break;;
					"KC")	showFiles KiranChemjong KC
					break;;
					"ZZ")	showFiles ZengZhi ZZ
					break;;
					"HK")	showFiles HarryKane HK
					break;;
					*)		echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
							echo "| Select the number form 1 to 3 |"
							echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
				esac
				$selectedPlayer 
			done
		else
			echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
			echo "| Enter only three codes with proper space ƪ(‾.‾“)┐ |"
			echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
			spectPlayers
		fi
		}
	#This function user is asked to enter the code of any three player, if player choose the correct player codes then player is taken to another phase 
	#If wrong player code is entered then an error messsage is displayed.
	choosePlayer(){
		echo "Type the player code of the player u want to choose!"
		echo "Choose any three players"
		read players
		firstCode=""
		secondCode=""
		thirdCode=""
		for player in $players
		do
			if [[ $player == "LM" || $player == "NJ" || $player == "KC" || $player == "ZZ" || $player == "HK" ]]
			then
				if [[ $firstCode == "" ]]
				then
					firstCode=$player
				elif [[ $secondCode == "" ]]
				then
					if [[ $firstCode == $player ]]
					then
						echo "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
						echo "    YOU CAN'T REPEATED THE CODE OF SAME PLAYER      "
						echo "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
						echo ""
						echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
						echo "      Please use three unique code for players      "
						echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
						echo ""
						choosePlayer
					else
						secondCode=$player
					fi
				elif [[ $firstCode == $player || $secondCode == $player ]]
					then
						echo "-----------------------------------------------------------------------------------"
						echo "| The player codes are repeated. Please try entering three unique player codes!!! |"
						echo "-----------------------------------------------------------------------------------"
					else
						chosenPlayer $players
					fi
				else
					echo "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
					echo "| PLEASE USE THE GIVEN CODES |"
					echo "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
					choosePlayer
			fi
		done
	}
	#The spectPlayers function shows the list of Football Players and calls the choosePlayer function.
	spectPlayers(){
		echo ""
		echo "Here are the world's greatest Football Players"
		echo "------------Phase 2-------------------"
		echo "--------Football Players--------------"
		echo "|   Player Name   |    Player Code   |"
		echo "--------------------------------------"
		echo " | Leonel Messi    >>  LM           |"
		echo " | Neymar Junior   >>  NJ           |"
		echo " | Kiran Chemjong  >>  KC           |"
		echo " | Zeng Zhi        >>  ZZ           |"
		echo " | Harry Kane      >>  HK           |"
		echo "--------------------------------------"
		echo "--------------------------------------"
		choosePlayer

	}
	#User is asked to choose any one country
	#If the user enters the correct code then the user is allowed to the another phase 
	#or an error message is give to the user and the phase is re executed until the user enters the correct country code
	selectTeam(){
		echo "/\                 \  
\_|                  |  
  |  select your team|  
  |                  |  
  |  ________________|_ 
  \_/_________________/
"
		echo "Use the provided codes to select a team, like NEP for Nepal"
		echo ""
		country=""
		until [ "$country" == BRZ ]
		do
			echo "------------------------------------------"
			echo -e "Enter the country code of your team:-\c"
			read country
			echo "------------------------------------------"
			case $country in
				BRZ) 
	echo "
	------------------------------------------------------"
	echo " 
	Congrats!!! you got the Correct Country!!! 
	Brazil is considered as the one to the strongest team in football by its rival.
	Brazil is the only team to win 5 worldcup"
	echo "
	------------------------------------------------------"
						echo ""
						spectPlayers
						;;
				ARG) echo "
Argentina is also one of the best team in worldcup. 
Argentina have won 2 worldcup but not the best team. 
Please try again!!!ƪ(‾.‾“)┐"
					echo ""
						;;
				NEP) echo "
Sorry!! Nepal is not a good choice and haven't played FIFA WORLDCUP even once. 
Please try Again!!!ƪ(‾.‾“)┐"
					echo ""
						;; 
				CHI) echo "
Sorry!! China is not a good choice and haven't won worldcup. 
Please try Again!!!ƪ(‾.‾“)┐"
					echo ""
						;;
				ENG) echo "
England is one of the best team in worldcup and have won 1 worldcup but not the best team. 
Please try again!!!ƪ(‾.‾“)┐"
					echo ""
						;;
				*) echo "Please Enter Correct Country code!(눈‸눈):"
					echo ""	
						;;
			esac
		done	
	}
	#The showCountry method shows the 5 country form which user needs to choose
	showCountry(){
	echo ""
	echo "Choose football team any one country"
	echo "----------------Phase 1---------------"
	echo "   -------------Teams-----------     "
	echo "  | Country Name | Country Code |     "
	echo "  -------------------------------     "
	echo "   | Brazil     >>  BRZ        |      "
	echo "   | Argentina  >>  ARG        |      "
	echo "   | Nepal      >>  NEP        |      "
	echo "   | China      >>  CHI        |      "
	echo "   | England    >>  ENG        |      "
	echo "   -----------------------------      "
	echo "   -----------------------------      "
	echo ""
	selectTeam
	}
	#The password function is use to secure the program, user won't be allow to start the program until the user enters the correct password.
	#Incase user enters the wrong password is entered by user, 4 chance is given to the user and after the 4th error message, the program will be terminated.
	password(){
		echo ""
		count=0
		passcode=77777
		until [ $count -gt 3 ]
		do
			read -sp "Enter the Password:" key
			if [ "$key" == "$passcode" ]
			then
				echo ""
				showCountry
			else
				echo ""
				echo "---------------------------------------------------------------------"
				echo "| Password is incorrect!!! You have used $(($count+1)) chance out of 4.|"
				echo "----------------------------------------------------------------------"
				((count++))
			fi
		done
		if [ $count == 4 ]
		then
			echo "----------------------------------------------------------"
			echo "| Sorry!!! You have entered the passcode wrong for 4 times.|"
			echo "----------------------------------------------------------"
			echo "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
			echo "          | THE PROGRAM HAVE BEEN TERMINATED |            "
			echo "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
			exit
		fi
	}
	# The userInput funcion give a welcome message to the user and ask for id and name
	userInput(){
	echo ""
	echo    "-  \||///
             / _  _ /
           (| (.)(.) |)
.--------.OOOo--()--oOOO.-------------.
|                                     |
|     Welcome to the Football World   | 
|                                     |
'----------.oooO----------------------'
           (   )   Oooo.
            \ (    (   )
             \_)    ) /
                   (_/"
	echo ""
	echo "| User ID: $1 |"
	echo "| Username:$2 |"
	password 
	}

	# If the two values in arguments are not found then an error message is displayed.
	if [ $# == 2 ]
	then
		userInput $1 $2 
	else
		echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
		echo "Provide both your Id and Name respectively, seperating them by space!!!! (╥﹏╥)"
		echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
	fi
	#program ends.
